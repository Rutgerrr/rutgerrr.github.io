export default {
  transitionTime: '150ms',
};
