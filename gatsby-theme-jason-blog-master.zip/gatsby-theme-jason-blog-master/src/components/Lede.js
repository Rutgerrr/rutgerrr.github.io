import styled from '@emotion/styled';

export default styled('p')`
  font-size: 110%;
  margin-top: 0.25rem;
`;
