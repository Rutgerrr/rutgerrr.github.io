import styled from '@emotion/styled';

export default styled('div')`
  margin-bottom: 5rem;
  margin-top: 3rem;
`;
