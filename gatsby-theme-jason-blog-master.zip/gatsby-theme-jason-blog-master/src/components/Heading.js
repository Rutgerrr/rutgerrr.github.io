import styled from '@emotion/styled';

export default styled('h1')`
  font-size: 1.5625rem;
  font-weight: 900;
  line-height: 1;
  margin: 0.5rem 0 0.25rem;
  text-align: center;
`;
