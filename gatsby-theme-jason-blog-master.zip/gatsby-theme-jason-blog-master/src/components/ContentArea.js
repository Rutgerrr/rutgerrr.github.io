import styled from '@emotion/styled';

export default styled('section')`
  > div > p:first-of-type {
    font-size: 112.5%;
  }
`;
