# Gatsby Theme: Jason’s Blog

This is a
[theme](https://www.gatsbyjs.org/blog/2018-11-11-introducing-gatsby-themes/) for
[Gatsby](https://www.gatsbyjs.org). I use it with my
[personal blog](https://lengstorf.com)
([source](https://github.com/jlengstorf/lengstorf.com)).

## Warning — Here Be Dragons

I’m still playing with the idea of theming, which means I’ll likely shuffle
multiple things around in here. If you decide to use this theme yourself, please
be aware that I might break things. (I’ll try not to, though. Promise.)
