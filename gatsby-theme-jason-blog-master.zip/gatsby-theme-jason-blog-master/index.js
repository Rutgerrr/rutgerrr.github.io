export { default as animation } from './src/tokens/animation';
export { default as colors } from './src/tokens/colors';
export { default as fonts } from './src/tokens/fonts';
export { default as media } from './src/tokens/media';
